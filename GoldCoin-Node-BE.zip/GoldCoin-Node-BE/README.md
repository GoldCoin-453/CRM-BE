# GoldCoin CRM – Backend API

REST API for the GoldCoin **Real Estate Lead Management CRM**.

**Stack:** Node.js 24 / 26 (ESM) · Express 5 · MongoDB (Mongoose 9) · Zod 4 · JWT · Pino · node:test

---

## 1. Quick start

```bash
# 1) Use the right Node version (24.2.0 by default – see docs/NODE_VERSION.md)
nvm use            # reads .nvmrc   (nvm-windows: nvm use 24.2.0)
npm run check:node

# 2) Install
npm ci             # or `npm install` the first time

# 3) Configure
cp .env.example .env      # Windows PowerShell: Copy-Item .env.example .env
#   -> set MONGODB_URI and JWT_SECRET

# 4) MongoDB (pick one)
#   a) Local Docker:  docker compose up -d mongo   (UI at http://localhost:8081)
#   b) MongoDB Atlas: paste the connection string into MONGODB_URI

# 5) Create first admin user
npm run seed:admin

# 6) Run
npm run dev        # auto-restart on change (node --watch)
```

API: `http://localhost:4000/api/v1` · Health: `http://localhost:4000/health`

Try it with `docs/requests.http` (VS Code **REST Client** extension).

## 2. Scripts

| Script               | What it does                                |
| -------------------- | ------------------------------------------- |
| `npm run dev`        | Start with auto-reload, reads `.env`        |
| `npm start`          | Start (production)                          |
| `npm test`           | Run tests (`node:test`)                     |
| `npm run lint`       | ESLint (`lint:fix` to auto-fix)             |
| `npm run format`     | Prettier write (`format:check` in CI)       |
| `npm run verify`     | lint + format check + tests – run before PR |
| `npm run seed:admin` | Create the first admin from `.env`          |
| `npm run check:node` | Confirm Node version is supported           |

## 3. Folder structure

```
GoldCoin-Node-BE/
├── .github/
│   ├── copilot-instructions.md   # Copilot rules (auto-loaded)
│   └── prompts/                  # Reusable Copilot prompts (/new-module ...)
├── .vscode/                      # Shared editor settings, debug configs
├── docs/                         # Architecture, API, Node version, Copilot prompt library
├── scripts/                      # seed-admin, check-node
├── src/
│   ├── app.js                    # Express app (no DB/listen) – used by tests
│   ├── server.js                 # Entry: DB connect, listen, graceful shutdown
│   ├── config/                   # env (zod-validated), database, logger
│   ├── common/
│   │   ├── constants/            # roles, lead enums
│   │   ├── errors/               # ApiError
│   │   ├── middlewares/          # auth, validate, errorHandler, rateLimiter, sanitize
│   │   ├── utils/                # apiResponse, pagination, jwt, regex
│   │   └── validation/           # shared zod schemas
│   ├── modules/
│   │   ├── auth/                 # login, me, change-password
│   │   ├── users/                # admin user management
│   │   ├── leads/                # lead CRUD, status, assign, notes
│   │   └── health/               # liveness / readiness
│   └── routes/index.js           # /api/v1 router
├── tests/
├── azure-pipelines.yml           # CI on Node 24 + 26, artifact, deploy template
├── Dockerfile / docker-compose.yml
└── .nvmrc / .node-version        # Node version pin
```

Each module follows: `model → validation → service → controller → routes`. See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## 4. Docs

- [Architecture & conventions](docs/ARCHITECTURE.md)
- [API reference](docs/API.md)
- [Switching Node 24 ↔ 26](docs/NODE_VERSION.md)
- [Copilot prompt library](docs/COPILOT_PROMPTS.md)
- [Team workflow & Azure DevOps](docs/CONTRIBUTING.md)
