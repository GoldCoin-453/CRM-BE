import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import { createApp } from '#src/app.js';

const app = createApp();

describe('App basics', () => {
  it('GET /health returns ok', async () => {
    const res = await request(app).get('/health');
    assert.equal(res.status, 200);
    assert.equal(res.body.status, 'ok');
    assert.ok(res.headers['x-request-id']);
  });

  it('GET /health/ready returns 503 when DB is not connected', async () => {
    const res = await request(app).get('/health/ready');
    assert.equal(res.status, 503);
    assert.equal(res.body.database, false);
  });

  it('unknown route returns 404 in standard error shape', async () => {
    const res = await request(app).get('/api/v1/does-not-exist');
    assert.equal(res.status, 404);
    assert.equal(res.body.success, false);
    assert.equal(res.body.error.code, 'NOT_FOUND');
  });

  it('malformed JSON returns 400', async () => {
    const res = await request(app)
      .post('/api/v1/auth/login')
      .set('Content-Type', 'application/json')
      .send('{"email": ');
    assert.equal(res.status, 400);
    assert.equal(res.body.error.message, 'Malformed JSON body');
  });

  it('login validates body before touching the DB', async () => {
    const res = await request(app).post('/api/v1/auth/login').send({ email: 'not-an-email' });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'VALIDATION_ERROR');
    const fields = res.body.error.details.map((d) => d.field);
    assert.ok(fields.includes('body.email'));
    assert.ok(fields.includes('body.password'));
  });
});

describe('Auth protection', () => {
  it('rejects requests without a token', async () => {
    const res = await request(app).get('/api/v1/leads');
    assert.equal(res.status, 401);
  });

  it('rejects requests with an invalid token', async () => {
    const res = await request(app).get('/api/v1/leads').set('Authorization', 'Bearer abc.def.ghi');
    assert.equal(res.status, 401);
    assert.equal(res.body.error.code, 'INVALID_TOKEN');
  });
});
