import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  changeStatusSchema,
  createLeadSchema,
  listLeadsQuery,
  updateLeadSchema,
} from '#modules/leads/lead.validation.js';

describe('Lead validation', () => {
  it('accepts a valid lead', () => {
    const result = createLeadSchema.safeParse({
      fullName: 'Rahul Sharma',
      phone: '+91 98765 43210',
      email: 'Rahul@Example.com',
      source: '99acres',
      requirement: {
        propertyType: 'apartment',
        bhk: '2BHK',
        budgetMin: 5000000,
        budgetMax: 7500000,
      },
    });
    assert.equal(result.success, true);
    assert.equal(result.data.email, 'rahul@example.com');
  });

  it('rejects invalid phone and unknown fields', () => {
    const result = createLeadSchema.safeParse({ fullName: 'A B', phone: 'abc', hacker: true });
    assert.equal(result.success, false);
  });

  it('rejects budgetMin > budgetMax', () => {
    const result = createLeadSchema.safeParse({
      fullName: 'Test Lead',
      phone: '9876543210',
      requirement: { budgetMin: 100, budgetMax: 50 },
    });
    assert.equal(result.success, false);
  });

  it('partial update does not inject default values', () => {
    const result = updateLeadSchema.safeParse({ city: 'Pune' });
    assert.equal(result.success, true);
    assert.deepEqual(result.data, { city: 'Pune' });
  });

  it('empty update is rejected', () => {
    assert.equal(updateLeadSchema.safeParse({}).success, false);
  });

  it('lost status requires lostReason', () => {
    assert.equal(changeStatusSchema.safeParse({ status: 'lost' }).success, false);
    assert.equal(
      changeStatusSchema.safeParse({ status: 'lost', lostReason: 'Budget mismatch' }).success,
      true,
    );
  });

  it('list query coerces and defaults pagination', () => {
    const result = listLeadsQuery.parse({ page: '2' });
    assert.equal(result.page, 2);
    assert.equal(result.limit, 20);
    assert.equal(result.sort, '-createdAt');
  });
});
