# Architecture & Conventions

## Request flow

```
Request
  → helmet / cors / compression / json parser
  → pino-http (request id + logging)
  → sanitize (strip $ / . keys)
  → rate limiter
  → module router
      → authenticate (JWT)        → req.user
      → authorize(roles)          → 403 if role not allowed
      → validate({ params, query, body })  → req.validated
      → controller (thin)
          → service (business logic + Mongoose)
      → sendSuccess(...)
  → notFound / errorHandler (any thrown error → standard JSON)
```

## Layers

| Layer          | Responsibility                                    | Must NOT              |
| -------------- | ------------------------------------------------- | --------------------- |
| `*.routes`     | Wire middlewares + controller                     | contain logic         |
| `*.validation` | Zod schemas for params/query/body                 | touch the DB          |
| `*.controller` | Read `req.validated`, call service, send response | query DB, try/catch   |
| `*.service`    | Business rules, access scope, DB access           | use `req`/`res`       |
| `*.model`      | Schema, defaults, indexes, hooks                  | contain HTTP concerns |

## Response format

```jsonc
// success
{ "success": true, "message": "OK", "data": { }, "meta": { "page": 1, "limit": 20, "total": 57, "totalPages": 3, "hasNextPage": true, "hasPrevPage": false } }

// error
{ "success": false, "error": { "code": "VALIDATION_ERROR", "message": "Validation failed", "details": [{ "field": "body.phone", "message": "Invalid phone number" }] }, "requestId": "..." }
```

## Error handling

- Throw `ApiError.*` anywhere. Express 5 catches rejected promises automatically.
- Mongoose validation / cast / duplicate key and JWT errors are converted automatically in `errorHandler.js`.
- 5xx errors are logged with stack; stack is returned to the client only outside production.

## Access control

| Role      | Users              | Leads                                                        |
| --------- | ------------------ | ------------------------------------------------------------ |
| `admin`   | create/update/list | all, delete, assign                                          |
| `manager` | list/view          | all, delete, assign                                          |
| `agent`   | –                  | only leads assigned to them; new leads auto-assigned to self |

## Adding a module (checklist)

1. Copy `src/modules/leads` structure (or use Copilot prompt `/new-module`).
2. Add enums to `src/common/constants`.
3. Register router in `src/routes/index.js`.
4. Add tests + update `docs/API.md`.
5. `npm run verify`.

## Environment

All env vars are validated in `src/config/env.js` on startup. Add new ones there **and** to `.env.example`. In Azure, set them under **App Service → Configuration** or an Azure DevOps **Variable Group** (Key Vault-linked for secrets).
