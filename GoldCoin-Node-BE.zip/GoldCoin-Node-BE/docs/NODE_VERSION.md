# Node.js version – 24.2.0 today, 26.13.1 tomorrow

The project supports **Node `>=24.2.0 <27`** (see `engines` in `package.json`).
CI runs every build on **both Node 24 and Node 26**, so switching is always tested.

## Why switching is safe here

- **No native modules** (no node-gyp): `bcryptjs` instead of `bcrypt`, pure-JS deps only → nothing to recompile.
- Uses only stable built-ins available in 24 and 26: `--watch`, `--env-file`, `node:test`, ESM, `imports` aliases.
- `engine-strict=true` in `.npmrc` → `npm install` fails immediately on an unsupported version instead of breaking later.
- Version pinned in `.nvmrc` and `.node-version` → nvm / fnm / Volta / Azure all read the same value.

## Windows (nvm-windows) – recommended for the team

```powershell
# install once: https://github.com/coreybutler/nvm-windows/releases
nvm install 24.2.0
nvm install 26.13.1

nvm use 24.2.0      # or: nvm use 26.13.1  (run terminal as Administrator if it fails)
node -v
npm run check:node
```

## macOS / Linux (nvm)

```bash
nvm install          # installs version from .nvmrc
nvm use
```

`fnm` users: `fnm use` (auto-reads `.node-version`).

## Switching the whole project to 26.13.1

1. Update the pin files:
   ```
   .nvmrc          → 26.13.1
   .node-version   → 26.13.1
   ```
2. Locally:
   ```bash
   nvm install 26.13.1 && nvm use 26.13.1
   rm -rf node_modules       # PowerShell: Remove-Item -Recurse -Force node_modules
   npm ci
   npm run verify
   ```
3. `azure-pipelines.yml` → change `primaryNodeVersion: '26.x'` (the test matrix already covers 26).
4. `Dockerfile` → `ARG NODE_VERSION=26.13.1` (or `docker build --build-arg NODE_VERSION=26.13.1 .`).
5. Azure App Service → **Configuration → General settings → Stack: Node 26** (or `runtimeStack: 'NODE|26-lts'` in the deploy step).
6. Commit as one PR: `chore: upgrade Node to 26.13.1`.

Rollback = revert that PR and `nvm use 24.2.0 && npm ci`.

## Always after switching versions

```bash
rm -rf node_modules && npm ci
```

Never copy `node_modules` between machines or Node versions.
