# API Reference (v1)

Base URL: `/api/v1` · Auth: `Authorization: Bearer <accessToken>`

## Health

| Method | Path            | Auth | Description                   |
| ------ | --------------- | ---- | ----------------------------- |
| GET    | `/health`       | –    | Liveness                      |
| GET    | `/health/ready` | –    | Readiness (503 if DB is down) |

## Auth

| Method | Path                    | Auth | Body                               |
| ------ | ----------------------- | ---- | ---------------------------------- |
| POST   | `/auth/login`           | –    | `{ email, password }`              |
| GET    | `/auth/me`              | ✔    | –                                  |
| PATCH  | `/auth/change-password` | ✔    | `{ currentPassword, newPassword }` |

## Users (admin / manager)

| Method | Path         | Roles          | Notes                                      |
| ------ | ------------ | -------------- | ------------------------------------------ |
| GET    | `/users`     | admin, manager | `?page&limit&role&isActive&search`         |
| POST   | `/users`     | admin          | `{ name, email, password, phone?, role? }` |
| GET    | `/users/:id` | admin, manager |                                            |
| PATCH  | `/users/:id` | admin          | `{ name?, phone?, role?, isActive? }`      |

## Leads

| Method | Path                | Roles          | Notes                                                                               |
| ------ | ------------------- | -------------- | ----------------------------------------------------------------------------------- |
| GET    | `/leads`            | all            | `?page&limit&sort&status&source&priority&assignedTo&search&followUpFrom&followUpTo` |
| POST   | `/leads`            | all            | 409 if phone already exists                                                         |
| GET    | `/leads/:id`        | all (scoped)   | includes notes                                                                      |
| PATCH  | `/leads/:id`        | all (scoped)   | partial update (not status/assignee)                                                |
| DELETE | `/leads/:id`        | admin, manager | soft delete                                                                         |
| PATCH  | `/leads/:id/status` | all (scoped)   | `{ status, lostReason?, note?, nextFollowUpAt? }`                                   |
| PATCH  | `/leads/:id/assign` | admin, manager | `{ assignedTo }`                                                                    |
| POST   | `/leads/:id/notes`  | all (scoped)   | `{ text }`                                                                          |

### Create lead – example

```json
{
  "fullName": "Rahul Sharma",
  "phone": "+91 98765 43210",
  "email": "rahul@example.com",
  "city": "Pune",
  "source": "99acres",
  "priority": "high",
  "projectName": "GoldCoin Heights",
  "requirement": {
    "purpose": "buy",
    "propertyType": "apartment",
    "bhk": "2BHK",
    "budgetMin": 5000000,
    "budgetMax": 7500000,
    "preferredLocations": ["Baner", "Wakad"]
  },
  "nextFollowUpAt": "2026-11-20T10:30:00+05:30",
  "note": "Interested in east-facing flat"
}
```

### Enums

- **status**: `new, contacted, qualified, site_visit_scheduled, site_visit_done, negotiation, booked, lost`
- **source**: `website, walk_in, referral, channel_partner, 99acres, magicbricks, housing, facebook, google_ads, whatsapp, other`
- **priority**: `low, medium, high, hot`
- **propertyType**: `apartment, villa, plot, independent_house, commercial, office, shop`
- **purpose**: `buy, rent, invest`
