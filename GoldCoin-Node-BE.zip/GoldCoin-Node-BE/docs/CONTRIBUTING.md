# Team Workflow & Azure DevOps Setup

## 1. Push this code to Azure Repos (one-time, by team lead)

```bash
cd GoldCoin-Node-BE
git init -b main
git add .
git commit -m "chore: initial backend scaffold"
git remote add origin https://dev.azure.com/<org>/<project>/_git/GoldCoin-Node-BE
git push -u origin main
git checkout -b develop && git push -u origin develop
```

## 2. Pipeline (one-time)

1. **Pipelines → New pipeline → Azure Repos Git →** select repo → **Existing Azure Pipelines YAML file** → `/azure-pipelines.yml` → Run.
2. **Repos → Branches → main / develop → Branch policies:**
   - Require a minimum number of reviewers: **1–2**
   - Check for linked work items: **On**
   - Build validation: add the pipeline above (**Required**)
   - Limit merge types: **Squash merge**
3. Secrets: **Pipelines → Library → Variable group** `goldcoin-api-dev` (link Azure Key Vault for `MONGODB_URI`, `JWT_SECRET`). Never commit `.env`.

## 3. Branching

```
main      ← production (protected)
develop   ← integration (protected)
feature/<workitem-id>-short-name   e.g. feature/123-site-visits
bugfix/<workitem-id>-short-name
hotfix/<workitem-id>-short-name    (from main)
```

## 4. Commit messages (Conventional Commits)

```
feat(leads): add follow-up overdue endpoint  #123
fix(auth): return 401 on expired token  #130
chore: upgrade Node to 26.13.1
docs(api): document site visits
test(leads): add duplicate phone test
```

Add `#<workItemId>` to link Azure Boards items.

## 5. Developer flow

1. Pick a work item in Azure Boards, create branch from `develop`.
2. Build with Copilot (`docs/COPILOT_PROMPTS.md`) following `.github/copilot-instructions.md`.
3. `npm run verify` must pass locally.
4. Push, open PR to `develop`, run `/code-review` in Copilot, fix comments.
5. Squash-merge after approval + green pipeline.

## 6. Definition of done

- [ ] Zod validation for all inputs, `req.validated` used
- [ ] Auth + role checks + agent scope
- [ ] Service holds the logic, controller is thin
- [ ] Indexes for new filters
- [ ] Tests added, `npm run verify` green
- [ ] `docs/API.md` and `.env.example` updated if needed
