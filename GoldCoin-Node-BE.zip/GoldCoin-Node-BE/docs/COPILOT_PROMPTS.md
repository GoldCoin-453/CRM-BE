# Copilot Prompt Library – GoldCoin CRM API

## How Copilot is set up in this repo

- **`.github/copilot-instructions.md`** – project rules, loaded automatically into every Copilot Chat request. You don't need to repeat the rules in your prompts.
- **`.github/prompts/*.prompt.md`** – reusable prompts. In Copilot Chat type `/` and pick:
  - `/new-module` – full module (model, validation, service, controller, routes, tests)
  - `/new-endpoint` – one endpoint in an existing module
  - `/write-tests` – tests with node:test + supertest
  - `/code-review` – review before raising a PR
- Use **Agent mode** for prompts that create multiple files. Always finish with `npm run verify`.

**Tips:** attach context with `#file:src/modules/leads/lead.service.js` so Copilot copies the pattern; build one module per chat; review the diff before accepting.

---

## Ready prompts – roadmap order

Copy-paste each one into Copilot Chat (Agent mode). They build on each other.

### 1. Properties / Projects inventory

```
/new-module moduleName=properties
Real estate inventory. A Project (name, builder, city, locality, address, reraNumber, status: upcoming|under_construction|ready_to_move, amenities[], images[] urls) has many Units.
Create two modules: `projects` and `units`.
Unit: project ref, tower, floor, unitNumber, bhk, carpetAreaSqft, superAreaSqft, facing, price, status: available|on_hold|booked|sold.
Unique index on (project, tower, unitNumber). Only admin/manager can create/update; all roles can list/view.
Add GET /projects/:id/units with filters bhk, status, minPrice, maxPrice.
```

### 2. Site visits

```
/new-module moduleName=site-visits
Track site visits for leads. Fields: lead (ref Lead, required), project (ref Project), scheduledAt (required), assignedTo (ref User), status: scheduled|completed|cancelled|no_show, feedback, rating 1-5, createdBy.
Rules: agents can only create/see visits for their own leads. When a visit is created set the lead status to site_visit_scheduled; when completed set lead status to site_visit_done. Do this in the service using the lead service, not in the controller.
Endpoints: CRUD + PATCH /site-visits/:id/complete { feedback, rating } and PATCH /site-visits/:id/cancel { reason }.
Filters: date range, status, assignedTo, lead.
```

### 3. Follow-ups & reminders

```
/new-endpoint moduleName=leads route="GET /leads/follow-ups/today and GET /leads/follow-ups/overdue" roles="all (agents scoped)" behaviour="Return leads whose nextFollowUpAt is today (Asia/Kolkata timezone) or before now and status not booked/lost. Paginated, sorted by nextFollowUpAt asc. Register these routes before /:id."
```

### 4. Activity log (audit trail)

```
/new-module moduleName=activities
Immutable activity log for leads: lead ref, type (created|status_changed|assigned|note_added|call|whatsapp|email|site_visit), message, meta (Mixed), performedBy, createdAt.
Create an `activity.service.js` with `logActivity({ leadId, type, message, meta, userId })` and call it from lead.service.js on create, status change, assign and note.
Endpoint: GET /leads/:id/activities (paginated, newest first). No update/delete endpoints.
```

### 5. Dashboard / reports

```
/new-module moduleName=dashboard
Read-only reporting endpoints using MongoDB aggregation on leads (exclude isDeleted). Agents get only their own numbers.
- GET /dashboard/summary?from&to → total leads, by status, by source, booked count, conversion rate %, leads created today
- GET /dashboard/agents-performance?from&to (admin/manager) → per agent: assigned, contacted, site visits done, booked, conversion %
- GET /dashboard/source-performance?from&to → per source: leads, booked, conversion %
Validate date range with zod (max 366 days). Add needed indexes.
```

### 6. Bulk lead import (CSV / Excel)

```
Add POST /leads/import (admin, manager) that accepts a CSV file upload (multer memory storage, max 5MB, .csv only).
Parse with `csv-parse` (pure JS). Validate every row with createLeadSchema, skip duplicates by phone (also duplicates inside the file), insert valid rows with insertMany in batches of 500.
Respond with { total, inserted, duplicates, failed: [{ row, errors }] }. Add a sample CSV in docs/samples/leads-import.csv. Add tests for the parser function.
```

### 7. Website / portal lead capture (public webhook)

```
Add a public endpoint POST /public/leads for website forms and portals (99acres, MagicBricks, Housing, Facebook Lead Ads).
Protect with an API key header `x-api-key` validated against env var LEAD_WEBHOOK_KEYS (comma separated) - add to env.js and .env.example.
Rate limit 60/min per IP. Map the payload to our lead fields, set source from a `source` field, createdBy = a system user (create SYSTEM user in seed script).
Auto-assign: round-robin among active agents (store a counter in a `settings` collection with atomic $inc).
```

### 8. Refresh tokens & logout

```
Implement refresh tokens in the auth module:
- Login returns accessToken (15m) + refreshToken (7d). Store hashed refresh tokens in a `sessions` collection (user, tokenHash, userAgent, ip, expiresAt with TTL index, revokedAt).
- POST /auth/refresh rotates the refresh token (revoke old, issue new); reuse of a revoked token revokes all user sessions.
- POST /auth/logout revokes the current session.
Add JWT_REFRESH_SECRET and JWT_REFRESH_EXPIRES_IN to env.js and .env.example. Add tests.
```

### 9. Forgot / reset password

```
Add POST /auth/forgot-password { email } and POST /auth/reset-password { token, newPassword }.
Generate a random token with crypto, store only its SHA-256 hash and expiry (30 min) on the user. Always return 200 for forgot-password (don't reveal emails).
Create `src/common/services/mail.service.js` interface with a console transport for dev (real provider later).
```

### 10. Swagger / OpenAPI docs

```
Add OpenAPI 3.1 documentation served at /api-docs using swagger-ui-express.
Generate schemas from our zod schemas using zod's built-in z.toJSONSchema(). Document every route in auth, users and leads with request/response examples and bearer auth. Disable /api-docs in production unless ENABLE_API_DOCS=true (add to env.js).
```

### 11. Integration tests with in-memory MongoDB

```
Add integration tests using mongodb-memory-server.
Create tests/helpers/db.js (start/stop/clear) and tests/helpers/auth.js (create user + get token for each role).
Write tests/leads.integration.test.js covering: create lead, duplicate phone 409, agent cannot see other agent's lead (404), manager assign, status change to lost requires reason, soft delete hides lead.
Add script "test:integration" and keep `npm test` fast (unit only).
```

### 12. WhatsApp / call logging

```
/new-module moduleName=communications
Log calls/WhatsApp/emails against a lead: lead ref, channel (call|whatsapp|email|sms), direction (inbound|outbound), outcome (connected|not_reachable|busy|callback_requested|interested|not_interested), durationSeconds, summary, performedBy.
On create update lead.lastContactedAt and, if lead status is new, move it to contacted. Log an activity.
```

---

## Prompts for daily work

- **Explain code:** `Explain how #file:src/common/middlewares/validate.js works and how to use it in a new route.`
- **Fix a bug:** `This request returns 500: <paste request + error log with requestId>. Find the root cause and fix it following project rules. Add a regression test.`
- **Add a field:** `Add field "budgetCurrency" (INR default) to Lead: model, validation, docs/API.md, tests.`
- **Add an index:** `Review lead.service.js listLeads filters and suggest missing MongoDB compound indexes.`
- **Before PR:** `/code-review scope=#changes`
