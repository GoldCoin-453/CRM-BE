// Prints the current Node version and whether it satisfies package.json "engines".
// Usage: npm run check:node
import { readFileSync } from 'node:fs';

const pkg = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
const [major, minor, patch] = process.versions.node.split('.').map(Number);
const current = major * 1e6 + minor * 1e3 + patch;
const MIN = 24 * 1e6 + 2 * 1e3; // 24.2.0
const MAX_MAJOR_EXCLUSIVE = 27;

const ok = current >= MIN && major < MAX_MAJOR_EXCLUSIVE;
console.log(
  `Node ${process.version} | required: ${pkg.engines.node} | ${ok ? 'OK ✅' : 'NOT SUPPORTED ❌'}`,
);
if (!ok) {
  console.log('Switch with:  nvm use 24.2.0   or   nvm use 26.13.1   (see docs/NODE_VERSION.md)');
  process.exit(1);
}
