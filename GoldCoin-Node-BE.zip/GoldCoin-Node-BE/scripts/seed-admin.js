// Creates the first admin user if it does not exist.
// Usage: set ADMIN_NAME / ADMIN_EMAIL / ADMIN_PASSWORD in .env, then `npm run seed:admin`
import { connectDatabase, disconnectDatabase } from '#config/database.js';
import { User } from '#modules/users/user.model.js';
import { ROLES } from '#common/constants/roles.js';

const { ADMIN_NAME = 'Super Admin', ADMIN_EMAIL, ADMIN_PASSWORD } = process.env;

if (!ADMIN_EMAIL || !ADMIN_PASSWORD) {
  console.error('ADMIN_EMAIL and ADMIN_PASSWORD are required in .env');
  process.exit(1);
}

try {
  await connectDatabase();
  const existing = await User.findOne({ email: ADMIN_EMAIL.toLowerCase() });
  if (existing) {
    console.log(`Admin already exists: ${existing.email}`);
  } else {
    const admin = await User.create({
      name: ADMIN_NAME,
      email: ADMIN_EMAIL,
      password: ADMIN_PASSWORD,
      role: ROLES.ADMIN,
    });
    console.log(`Admin created: ${admin.email}`);
  }
} catch (err) {
  console.error('Seed failed:', err.message);
  process.exitCode = 1;
} finally {
  await disconnectDatabase();
}
