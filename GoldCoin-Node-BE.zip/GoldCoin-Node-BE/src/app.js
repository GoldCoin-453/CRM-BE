import { randomUUID } from 'node:crypto';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import compression from 'compression';
import { pinoHttp } from 'pino-http';

import { env } from '#config/env.js';
import { logger } from '#config/logger.js';
import { sanitizeInput } from '#common/middlewares/sanitize.js';
import { apiLimiter } from '#common/middlewares/rateLimiter.js';
import { notFound } from '#common/middlewares/notFound.js';
import { errorHandler } from '#common/middlewares/errorHandler.js';
import healthRoutes from '#modules/health/health.routes.js';
import apiRoutes from '#src/routes/index.js';

/**
 * Builds the Express app WITHOUT connecting to the DB or listening on a port,
 * so tests can import it directly.
 */
export function createApp() {
  const app = express();

  app.disable('x-powered-by');
  app.set('trust proxy', 1); // Azure App Service / load balancer in front

  // Security & parsing
  app.use(helmet());
  app.use(cors({ origin: env.corsOrigins, credentials: true }));
  app.use(compression());
  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: true, limit: '1mb' }));

  // Request logging + request id (returned as `x-request-id` header)
  app.use(
    pinoHttp({
      logger,
      genReqId: (req, res) => {
        const id = req.headers['x-request-id'] ?? randomUUID();
        res.setHeader('x-request-id', id);
        return id;
      },
      autoLogging: { ignore: (req) => req.url.startsWith('/health') },
    }),
  );

  app.use(sanitizeInput);

  // Routes
  app.use('/health', healthRoutes);
  app.use(env.API_PREFIX, apiLimiter, apiRoutes);

  // 404 + error handler must be last
  app.use(notFound);
  app.use(errorHandler);

  return app;
}
