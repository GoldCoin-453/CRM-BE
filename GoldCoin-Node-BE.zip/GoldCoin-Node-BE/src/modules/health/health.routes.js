import { Router } from 'express';
import { isDatabaseReady } from '#config/database.js';

const router = Router();

/** Liveness - is the process up? (Azure App Service health check path) */
router.get('/', (_req, res) => {
  res.json({
    status: 'ok',
    uptime: Math.round(process.uptime()),
    timestamp: new Date().toISOString(),
    node: process.version,
  });
});

/** Readiness - can we serve traffic (DB connected)? */
router.get('/ready', (_req, res) => {
  const db = isDatabaseReady();
  res.status(db ? 200 : 503).json({ status: db ? 'ready' : 'not_ready', database: db });
});

export default router;
