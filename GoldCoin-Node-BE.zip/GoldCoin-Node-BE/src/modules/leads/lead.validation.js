import { z } from 'zod';
import {
  LEAD_PRIORITY_VALUES,
  LEAD_PURPOSE_VALUES,
  LEAD_SOURCE_VALUES,
  LEAD_STATUS,
  LEAD_STATUS_VALUES,
  PROPERTY_TYPE_VALUES,
} from '#common/constants/lead.js';
import { objectId, phone } from '#common/validation/common.schemas.js';
import { paginationQuery } from '#common/utils/pagination.js';

// NOTE: no `.default()` in body schemas - defaults live in the Mongoose model.
// (In zod 4 defaults also apply inside .partial(), which would overwrite data on PATCH.)

const requirementSchema = z
  .strictObject({
    purpose: z.enum(LEAD_PURPOSE_VALUES).optional(),
    propertyType: z.enum(PROPERTY_TYPE_VALUES).optional(),
    bhk: z.string().trim().max(20).optional(),
    budgetMin: z.number().nonnegative().optional(),
    budgetMax: z.number().nonnegative().optional(),
    preferredLocations: z.array(z.string().trim().min(1).max(100)).max(20).optional(),
  })
  .refine((r) => r.budgetMin == null || r.budgetMax == null || r.budgetMin <= r.budgetMax, {
    message: 'budgetMin must be less than or equal to budgetMax',
    path: ['budgetMax'],
  });

const leadFields = {
  fullName: z.string().trim().min(2).max(120),
  phone,
  alternatePhone: phone.optional(),
  email: z.email().toLowerCase().optional(),
  city: z.string().trim().max(100).optional(),
  source: z.enum(LEAD_SOURCE_VALUES).optional(),
  priority: z.enum(LEAD_PRIORITY_VALUES).optional(),
  projectName: z.string().trim().max(150).optional(),
  requirement: requirementSchema.optional(),
  assignedTo: objectId.optional(),
  nextFollowUpAt: z.coerce.date().optional(),
  tags: z.array(z.string().trim().min(1).max(50)).max(20).optional(),
};

export const createLeadSchema = z.strictObject({
  ...leadFields,
  note: z.string().trim().min(1).max(2000).optional(), // optional first note
});

// Status, assignment and notes have dedicated endpoints, so they are not editable here.
export const updateLeadSchema = z
  .strictObject(leadFields)
  .omit({ assignedTo: true })
  .partial()
  .refine((data) => Object.keys(data).length > 0, 'Provide at least one field to update');

export const changeStatusSchema = z
  .strictObject({
    status: z.enum(LEAD_STATUS_VALUES),
    lostReason: z.string().trim().min(3).max(500).optional(),
    note: z.string().trim().min(1).max(2000).optional(),
    nextFollowUpAt: z.coerce.date().optional(),
  })
  .refine((d) => d.status !== LEAD_STATUS.LOST || d.lostReason, {
    message: 'lostReason is required when status is "lost"',
    path: ['lostReason'],
  });

export const assignLeadSchema = z.strictObject({ assignedTo: objectId });

export const addNoteSchema = z.strictObject({ text: z.string().trim().min(1).max(2000) });

const SORT_FIELDS = ['createdAt', 'updatedAt', 'nextFollowUpAt', 'fullName'];

export const listLeadsQuery = z
  .object({
    ...paginationQuery,
    sort: z.enum([...SORT_FIELDS, ...SORT_FIELDS.map((f) => `-${f}`)]).default('-createdAt'),
    status: z.enum(LEAD_STATUS_VALUES).optional(),
    source: z.enum(LEAD_SOURCE_VALUES).optional(),
    priority: z.enum(LEAD_PRIORITY_VALUES).optional(),
    assignedTo: objectId.optional(),
    search: z.string().trim().min(1).max(100).optional(),
    followUpFrom: z.coerce.date().optional(),
    followUpTo: z.coerce.date().optional(),
  })
  .refine((q) => !q.followUpFrom || !q.followUpTo || q.followUpFrom <= q.followUpTo, {
    message: 'followUpFrom must be before followUpTo',
    path: ['followUpTo'],
  });
