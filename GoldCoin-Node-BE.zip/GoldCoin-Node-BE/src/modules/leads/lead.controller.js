import * as leadService from './lead.service.js';
import { sendSuccess } from '#common/utils/apiResponse.js';

// Controllers are thin: read req.validated -> call service -> send response.
// No business logic and no DB calls here.

export async function create(req, res) {
  const lead = await leadService.createLead(req.validated.body, req.user);
  sendSuccess(res, { statusCode: 201, message: 'Lead created', data: lead });
}

export async function list(req, res) {
  const { items, meta } = await leadService.listLeads(req.validated.query, req.user);
  sendSuccess(res, { data: items, meta });
}

export async function getById(req, res) {
  const lead = await leadService.getLeadById(req.validated.params.id, req.user);
  sendSuccess(res, { data: lead });
}

export async function update(req, res) {
  const lead = await leadService.updateLead(req.validated.params.id, req.validated.body, req.user);
  sendSuccess(res, { message: 'Lead updated', data: lead });
}

export async function changeStatus(req, res) {
  const lead = await leadService.changeStatus(
    req.validated.params.id,
    req.validated.body,
    req.user,
  );
  sendSuccess(res, { message: 'Lead status updated', data: lead });
}

export async function assign(req, res) {
  const lead = await leadService.assignLead(
    req.validated.params.id,
    req.validated.body.assignedTo,
    req.user,
  );
  sendSuccess(res, { message: 'Lead assigned', data: lead });
}

export async function addNote(req, res) {
  const note = await leadService.addNote(
    req.validated.params.id,
    req.validated.body.text,
    req.user,
  );
  sendSuccess(res, { statusCode: 201, message: 'Note added', data: note });
}

export async function remove(req, res) {
  await leadService.deleteLead(req.validated.params.id, req.user);
  sendSuccess(res, { message: 'Lead deleted' });
}
