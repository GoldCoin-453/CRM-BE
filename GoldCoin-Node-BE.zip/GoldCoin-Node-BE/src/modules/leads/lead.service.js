import { Lead } from './lead.model.js';
import { ApiError } from '#common/errors/ApiError.js';
import { ROLES } from '#common/constants/roles.js';
import { LEAD_STATUS } from '#common/constants/lead.js';
import { buildPaginationMeta, getSkip } from '#common/utils/pagination.js';
import { escapeRegex } from '#common/utils/regex.js';
import { isAssignableUser } from '#modules/users/user.service.js';

const POPULATE_ASSIGNEE = { path: 'assignedTo', select: 'name email phone role' };

/** Agents can only see/touch leads assigned to them. */
function accessScope(user) {
  return user.role === ROLES.AGENT ? { assignedTo: user.id } : {};
}

async function findAccessibleLeadOrThrow(id, user) {
  const exists = await Lead.exists({ _id: id, isDeleted: false, ...accessScope(user) });
  if (!exists) throw ApiError.notFound('Lead not found');
}

async function assertNoDuplicatePhone(phone, excludeId) {
  const filter = { phone, isDeleted: false };
  if (excludeId) filter._id = { $ne: excludeId };
  const existing = await Lead.findOne(filter).select('_id').lean();
  if (existing) {
    throw ApiError.conflict('A lead with this phone number already exists', {
      leadId: existing._id,
    });
  }
}

async function assertAssignable(userId) {
  if (!(await isAssignableUser(userId))) {
    throw ApiError.badRequest('assignedTo must be an active user');
  }
}

export async function createLead({ note, ...data }, user) {
  await assertNoDuplicatePhone(data.phone);

  if (user.role === ROLES.AGENT) {
    data.assignedTo = user.id; // agents always own the leads they create
  } else if (data.assignedTo) {
    await assertAssignable(data.assignedTo);
  }

  const lead = await Lead.create({
    ...data,
    createdBy: user.id,
    notes: note ? [{ text: note, createdBy: user.id }] : [],
  });
  return lead.populate(POPULATE_ASSIGNEE);
}

export async function listLeads(query, user) {
  const { page, limit, sort, search, followUpFrom, followUpTo, ...filters } = query;

  const filter = { isDeleted: false, ...filters, ...accessScope(user) };

  if (search) {
    const rx = new RegExp(escapeRegex(search), 'i');
    filter.$or = [{ fullName: rx }, { phone: rx }, { email: rx }, { projectName: rx }];
  }
  if (followUpFrom || followUpTo) {
    filter.nextFollowUpAt = {
      ...(followUpFrom && { $gte: followUpFrom }),
      ...(followUpTo && { $lte: followUpTo }),
    };
  }

  const [items, total] = await Promise.all([
    Lead.find(filter)
      .select('-notes')
      .sort(sort)
      .skip(getSkip(page, limit))
      .limit(limit)
      .populate(POPULATE_ASSIGNEE)
      .lean(),
    Lead.countDocuments(filter),
  ]);

  return { items, meta: buildPaginationMeta(page, limit, total) };
}

export async function getLeadById(id, user) {
  const lead = await Lead.findOne({ _id: id, isDeleted: false, ...accessScope(user) })
    .populate(POPULATE_ASSIGNEE)
    .populate({ path: 'notes.createdBy', select: 'name' })
    .lean();
  if (!lead) throw ApiError.notFound('Lead not found');
  return lead;
}

export async function updateLead(id, data, user) {
  await findAccessibleLeadOrThrow(id, user);
  if (data.phone) await assertNoDuplicatePhone(data.phone, id);

  // Note: `requirement` is replaced as a whole object - send the full requirement on update.
  return Lead.findByIdAndUpdate(
    id,
    { $set: data },
    { returnDocument: 'after', runValidators: true },
  )
    .populate(POPULATE_ASSIGNEE)
    .lean();
}

export async function changeStatus(id, { status, lostReason, note, nextFollowUpAt }, user) {
  await findAccessibleLeadOrThrow(id, user);

  const update = {
    $set: { status, lastContactedAt: new Date() },
  };
  if (status === LEAD_STATUS.LOST) update.$set.lostReason = lostReason;
  else update.$unset = { lostReason: 1 };
  if (nextFollowUpAt) update.$set.nextFollowUpAt = nextFollowUpAt;
  if (note) update.$push = { notes: { text: note, createdBy: user.id } };

  return Lead.findByIdAndUpdate(id, update, { returnDocument: 'after', runValidators: true })
    .populate(POPULATE_ASSIGNEE)
    .lean();
}

export async function assignLead(id, assignedTo, user) {
  await findAccessibleLeadOrThrow(id, user);
  await assertAssignable(assignedTo);

  return Lead.findByIdAndUpdate(id, { $set: { assignedTo } }, { returnDocument: 'after' })
    .populate(POPULATE_ASSIGNEE)
    .lean();
}

export async function addNote(id, text, user) {
  await findAccessibleLeadOrThrow(id, user);

  const lead = await Lead.findByIdAndUpdate(
    id,
    { $push: { notes: { text, createdBy: user.id } } },
    { returnDocument: 'after', runValidators: true },
  )
    .select('notes')
    .populate({ path: 'notes.createdBy', select: 'name' })
    .lean();

  return lead.notes.at(-1);
}

export async function deleteLead(id, user) {
  await findAccessibleLeadOrThrow(id, user);
  await Lead.updateOne({ _id: id }, { $set: { isDeleted: true } });
}
