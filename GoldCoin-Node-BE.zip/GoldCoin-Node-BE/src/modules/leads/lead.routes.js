import { Router } from 'express';
import * as controller from './lead.controller.js';
import {
  addNoteSchema,
  assignLeadSchema,
  changeStatusSchema,
  createLeadSchema,
  listLeadsQuery,
  updateLeadSchema,
} from './lead.validation.js';
import { authenticate, authorize } from '#common/middlewares/auth.js';
import { validate } from '#common/middlewares/validate.js';
import { idParams } from '#common/validation/common.schemas.js';
import { ROLES } from '#common/constants/roles.js';

const router = Router();

router.use(authenticate);

router
  .route('/')
  .get(validate({ query: listLeadsQuery }), controller.list)
  .post(validate({ body: createLeadSchema }), controller.create);

router
  .route('/:id')
  .get(validate({ params: idParams }), controller.getById)
  .patch(validate({ params: idParams, body: updateLeadSchema }), controller.update)
  .delete(authorize(ROLES.ADMIN, ROLES.MANAGER), validate({ params: idParams }), controller.remove);

router.patch(
  '/:id/status',
  validate({ params: idParams, body: changeStatusSchema }),
  controller.changeStatus,
);

router.patch(
  '/:id/assign',
  authorize(ROLES.ADMIN, ROLES.MANAGER),
  validate({ params: idParams, body: assignLeadSchema }),
  controller.assign,
);

router.post('/:id/notes', validate({ params: idParams, body: addNoteSchema }), controller.addNote);

export default router;
