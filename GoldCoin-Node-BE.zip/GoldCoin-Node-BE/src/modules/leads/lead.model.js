import mongoose from 'mongoose';
import {
  LEAD_PRIORITY,
  LEAD_PRIORITY_VALUES,
  LEAD_PURPOSE_VALUES,
  LEAD_SOURCE,
  LEAD_SOURCE_VALUES,
  LEAD_STATUS,
  LEAD_STATUS_VALUES,
  PROPERTY_TYPE_VALUES,
} from '#common/constants/lead.js';

const { Schema, model, models } = mongoose;

const noteSchema = new Schema(
  {
    text: { type: String, required: true, trim: true, maxlength: 2000 },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  },
  { timestamps: { createdAt: true, updatedAt: false } },
);

const requirementSchema = new Schema(
  {
    purpose: { type: String, enum: LEAD_PURPOSE_VALUES },
    propertyType: { type: String, enum: PROPERTY_TYPE_VALUES },
    bhk: { type: String, trim: true, maxlength: 20 }, // "2BHK", "3BHK+", ...
    budgetMin: { type: Number, min: 0 },
    budgetMax: { type: Number, min: 0 },
    preferredLocations: { type: [String], default: [] },
  },
  { _id: false },
);

const leadSchema = new Schema(
  {
    fullName: { type: String, required: true, trim: true, maxlength: 120 },
    phone: { type: String, required: true, trim: true },
    alternatePhone: { type: String, trim: true },
    email: { type: String, trim: true, lowercase: true },
    city: { type: String, trim: true },

    source: { type: String, enum: LEAD_SOURCE_VALUES, default: LEAD_SOURCE.WEBSITE },
    status: { type: String, enum: LEAD_STATUS_VALUES, default: LEAD_STATUS.NEW },
    priority: { type: String, enum: LEAD_PRIORITY_VALUES, default: LEAD_PRIORITY.MEDIUM },

    projectName: { type: String, trim: true }, // project/property the lead enquired about
    requirement: { type: requirementSchema, default: () => ({}) },

    assignedTo: { type: Schema.Types.ObjectId, ref: 'User' },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User', required: true },

    nextFollowUpAt: { type: Date },
    lastContactedAt: { type: Date },
    lostReason: { type: String, trim: true, maxlength: 500 },
    tags: { type: [String], default: [] },
    notes: { type: [noteSchema], default: [] },

    isDeleted: { type: Boolean, default: false }, // soft delete
  },
  { timestamps: true, versionKey: false },
);

// Indexes for the most common CRM queries
leadSchema.index({ phone: 1, isDeleted: 1 });
leadSchema.index({ assignedTo: 1, status: 1, createdAt: -1 });
leadSchema.index({ status: 1, createdAt: -1 });
leadSchema.index({ nextFollowUpAt: 1, assignedTo: 1 });

export const Lead = models.Lead ?? model('Lead', leadSchema);
