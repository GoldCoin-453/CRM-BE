import * as userService from './user.service.js';
import { sendSuccess } from '#common/utils/apiResponse.js';

export async function create(req, res) {
  const user = await userService.createUser(req.validated.body);
  sendSuccess(res, { statusCode: 201, message: 'User created', data: user });
}

export async function list(req, res) {
  const { items, meta } = await userService.listUsers(req.validated.query);
  sendSuccess(res, { data: items, meta });
}

export async function getById(req, res) {
  const user = await userService.getUserById(req.validated.params.id);
  sendSuccess(res, { data: user });
}

export async function update(req, res) {
  const user = await userService.updateUser(req.validated.params.id, req.validated.body, req.user);
  sendSuccess(res, { message: 'User updated', data: user });
}
