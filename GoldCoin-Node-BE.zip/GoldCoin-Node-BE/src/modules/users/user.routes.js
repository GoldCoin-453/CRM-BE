import { Router } from 'express';
import * as controller from './user.controller.js';
import { createUserSchema, listUsersQuery, updateUserSchema } from './user.validation.js';
import { authenticate, authorize } from '#common/middlewares/auth.js';
import { validate } from '#common/middlewares/validate.js';
import { idParams } from '#common/validation/common.schemas.js';
import { ROLES } from '#common/constants/roles.js';

const router = Router();

router.use(authenticate);

router
  .route('/')
  .get(authorize(ROLES.ADMIN, ROLES.MANAGER), validate({ query: listUsersQuery }), controller.list)
  .post(authorize(ROLES.ADMIN), validate({ body: createUserSchema }), controller.create);

router
  .route('/:id')
  .get(authorize(ROLES.ADMIN, ROLES.MANAGER), validate({ params: idParams }), controller.getById)
  .patch(
    authorize(ROLES.ADMIN),
    validate({ params: idParams, body: updateUserSchema }),
    controller.update,
  );

export default router;
