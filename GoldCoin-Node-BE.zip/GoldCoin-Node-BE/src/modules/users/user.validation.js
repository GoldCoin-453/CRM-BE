import { z } from 'zod';
import { ROLE_VALUES } from '#common/constants/roles.js';
import { phone } from '#common/validation/common.schemas.js';
import { paginationQuery } from '#common/utils/pagination.js';

export const password = z
  .string()
  .min(8, 'Password must be at least 8 characters')
  .max(72, 'Password must be at most 72 characters')
  .regex(/[A-Z]/, 'Password must contain an uppercase letter')
  .regex(/[a-z]/, 'Password must contain a lowercase letter')
  .regex(/[0-9]/, 'Password must contain a number');

export const createUserSchema = z.strictObject({
  name: z.string().trim().min(2).max(100),
  email: z.email().toLowerCase(),
  phone: phone.optional(),
  password,
  role: z.enum(ROLE_VALUES).optional(),
});

export const updateUserSchema = z
  .strictObject({
    name: z.string().trim().min(2).max(100),
    phone,
    role: z.enum(ROLE_VALUES),
    isActive: z.boolean(),
  })
  .partial()
  .refine((data) => Object.keys(data).length > 0, 'Provide at least one field to update');

export const listUsersQuery = z.object({
  ...paginationQuery,
  role: z.enum(ROLE_VALUES).optional(),
  isActive: z
    .enum(['true', 'false'])
    .transform((v) => v === 'true')
    .optional(),
  search: z.string().trim().max(100).optional(),
});
