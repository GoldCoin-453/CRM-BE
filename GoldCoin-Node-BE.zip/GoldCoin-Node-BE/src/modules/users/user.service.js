import { User } from './user.model.js';
import { ApiError } from '#common/errors/ApiError.js';
import { buildPaginationMeta, getSkip } from '#common/utils/pagination.js';
import { escapeRegex } from '#common/utils/regex.js';

export async function createUser(data) {
  const exists = await User.exists({ email: data.email });
  if (exists) throw ApiError.conflict('A user with this email already exists');
  return User.create(data);
}

export async function listUsers({ page, limit, search, ...filters }) {
  const filter = { ...filters };
  if (search) {
    const rx = new RegExp(escapeRegex(search), 'i');
    filter.$or = [{ name: rx }, { email: rx }, { phone: rx }];
  }

  const [items, total] = await Promise.all([
    User.find(filter).sort({ createdAt: -1 }).skip(getSkip(page, limit)).limit(limit).lean(),
    User.countDocuments(filter),
  ]);
  return { items, meta: buildPaginationMeta(page, limit, total) };
}

export async function getUserById(id) {
  const user = await User.findById(id).lean();
  if (!user) throw ApiError.notFound('User not found');
  return user;
}

export async function updateUser(id, data, currentUser) {
  if (id === currentUser.id && (data.role || data.isActive === false)) {
    throw ApiError.badRequest('You cannot change your own role or deactivate yourself');
  }
  const user = await User.findByIdAndUpdate(
    id,
    { $set: data },
    { returnDocument: 'after', runValidators: true },
  ).lean();
  if (!user) throw ApiError.notFound('User not found');
  return user;
}

/** True if the user exists and is active - used when assigning leads */
export async function isAssignableUser(id) {
  return Boolean(await User.exists({ _id: id, isActive: true }));
}
