import * as authService from './auth.service.js';
import { sendSuccess } from '#common/utils/apiResponse.js';

export async function login(req, res) {
  const result = await authService.login(req.validated.body);
  sendSuccess(res, { message: 'Login successful', data: result });
}

export async function me(req, res) {
  const user = await authService.getProfile(req.user.id);
  sendSuccess(res, { data: user });
}

export async function changePassword(req, res) {
  await authService.changePassword(req.user.id, req.validated.body);
  sendSuccess(res, { message: 'Password changed successfully' });
}
