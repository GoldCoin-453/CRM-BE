import { z } from 'zod';
import { password } from '#modules/users/user.validation.js';

export const loginSchema = z.strictObject({
  email: z.email().toLowerCase(),
  password: z.string().min(1, 'Password is required'),
});

export const changePasswordSchema = z
  .strictObject({
    currentPassword: z.string().min(1),
    newPassword: password,
  })
  .refine((d) => d.currentPassword !== d.newPassword, {
    message: 'New password must be different from current password',
    path: ['newPassword'],
  });
