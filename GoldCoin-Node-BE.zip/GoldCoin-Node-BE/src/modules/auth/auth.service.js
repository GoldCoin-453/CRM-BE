import { User } from '#modules/users/user.model.js';
import { ApiError } from '#common/errors/ApiError.js';
import { signAccessToken } from '#common/utils/jwt.js';

export async function login({ email, password }) {
  const user = await User.findOne({ email }).select('+password');
  // Same message for both cases - don't reveal which emails exist
  if (!user || !(await user.comparePassword(password))) {
    throw ApiError.unauthorized('Invalid email or password');
  }
  if (!user.isActive) throw ApiError.forbidden('Your account is deactivated');

  user.lastLoginAt = new Date();
  await user.save();

  return { accessToken: signAccessToken(user), tokenType: 'Bearer', user: user.toJSON() };
}

export async function getProfile(userId) {
  const user = await User.findById(userId).lean();
  if (!user) throw ApiError.notFound('User not found');
  return user;
}

export async function changePassword(userId, { currentPassword, newPassword }) {
  const user = await User.findById(userId).select('+password');
  if (!user || !(await user.comparePassword(currentPassword))) {
    throw ApiError.badRequest('Current password is incorrect');
  }
  user.password = newPassword;
  await user.save();
}
