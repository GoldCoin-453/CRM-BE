import { Router } from 'express';
import * as controller from './auth.controller.js';
import { changePasswordSchema, loginSchema } from './auth.validation.js';
import { authenticate } from '#common/middlewares/auth.js';
import { validate } from '#common/middlewares/validate.js';
import { authLimiter } from '#common/middlewares/rateLimiter.js';

const router = Router();

router.post('/login', authLimiter, validate({ body: loginSchema }), controller.login);
router.get('/me', authenticate, controller.me);
router.patch(
  '/change-password',
  authenticate,
  authLimiter,
  validate({ body: changePasswordSchema }),
  controller.changePassword,
);

export default router;
