import { Router } from 'express';
import authRoutes from '#modules/auth/auth.routes.js';
import userRoutes from '#modules/users/user.routes.js';
import leadRoutes from '#modules/leads/lead.routes.js';

/**
 * API v1 router - mounted at env.API_PREFIX (default /api/v1).
 * Register every new module here.
 */
const router = Router();

router.use('/auth', authRoutes);
router.use('/users', userRoutes);
router.use('/leads', leadRoutes);

export default router;
