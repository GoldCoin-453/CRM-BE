import pino from 'pino';
import { env } from './env.js';

/**
 * App-wide structured logger. Use `logger.info({ leadId }, 'Lead created')`
 * instead of console.log. Inside a request, prefer `req.log` (includes requestId).
 */
export const logger = pino({
  level: env.LOG_LEVEL,
  redact: {
    paths: ['req.headers.authorization', 'req.headers.cookie', '*.password', '*.token'],
    censor: '[REDACTED]',
  },
  ...(env.isDevelopment && {
    transport: {
      target: 'pino-pretty',
      options: { colorize: true, translateTime: 'SYS:HH:MM:ss', ignore: 'pid,hostname' },
    },
  }),
});
