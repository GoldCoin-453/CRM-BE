import jwt from 'jsonwebtoken';
import { env } from '#config/env.js';

const ISSUER = 'goldcoin-crm-api';

export function signAccessToken(user) {
  return jwt.sign({ role: user.role }, env.JWT_SECRET, {
    subject: String(user._id ?? user.id),
    expiresIn: env.JWT_EXPIRES_IN,
    issuer: ISSUER,
  });
}

/** Throws JsonWebTokenError / TokenExpiredError - handled by the error handler. */
export function verifyAccessToken(token) {
  return jwt.verify(token, env.JWT_SECRET, { issuer: ISSUER });
}
