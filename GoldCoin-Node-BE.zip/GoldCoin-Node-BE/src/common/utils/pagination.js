import { z } from 'zod';

/** Reusable zod fields for list endpoints: ?page=1&limit=20 */
export const paginationQuery = {
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
};

export function getSkip(page, limit) {
  return (page - 1) * limit;
}

export function buildPaginationMeta(page, limit, total) {
  const totalPages = Math.ceil(total / limit) || 0;
  return {
    page,
    limit,
    total,
    totalPages,
    hasNextPage: page < totalPages,
    hasPrevPage: page > 1,
  };
}
