/** Escape user input before using it in a RegExp (prevents ReDoS / regex injection). */
export function escapeRegex(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
