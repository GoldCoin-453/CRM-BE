/**
 * Every successful response has the same shape:
 * { success: true, message, data, meta? }
 */
export function sendSuccess(res, { data = null, message = 'OK', meta, statusCode = 200 } = {}) {
  const body = { success: true, message, data };
  if (meta) body.meta = meta;
  return res.status(statusCode).json(body);
}
