import { z } from 'zod';

/** MongoDB ObjectId as a 24-char hex string */
export const objectId = z.string().regex(/^[a-f\d]{24}$/i, 'Invalid id');

/** Accepts +91 98765 43210, 9876543210, 022-12345678 ... */
export const phone = z
  .string()
  .trim()
  .regex(/^\+?[0-9][0-9\s-]{6,19}$/, 'Invalid phone number');

export const idParams = z.object({ id: objectId });
