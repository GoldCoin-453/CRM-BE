export const LEAD_STATUS = Object.freeze({
  NEW: 'new',
  CONTACTED: 'contacted',
  QUALIFIED: 'qualified',
  SITE_VISIT_SCHEDULED: 'site_visit_scheduled',
  SITE_VISIT_DONE: 'site_visit_done',
  NEGOTIATION: 'negotiation',
  BOOKED: 'booked', // won
  LOST: 'lost',
});

export const LEAD_SOURCE = Object.freeze({
  WEBSITE: 'website',
  WALK_IN: 'walk_in',
  REFERRAL: 'referral',
  CHANNEL_PARTNER: 'channel_partner',
  PORTAL_99ACRES: '99acres',
  PORTAL_MAGICBRICKS: 'magicbricks',
  PORTAL_HOUSING: 'housing',
  FACEBOOK: 'facebook',
  GOOGLE_ADS: 'google_ads',
  WHATSAPP: 'whatsapp',
  OTHER: 'other',
});

export const LEAD_PRIORITY = Object.freeze({
  LOW: 'low',
  MEDIUM: 'medium',
  HIGH: 'high',
  HOT: 'hot',
});

export const PROPERTY_TYPE = Object.freeze({
  APARTMENT: 'apartment',
  VILLA: 'villa',
  PLOT: 'plot',
  INDEPENDENT_HOUSE: 'independent_house',
  COMMERCIAL: 'commercial',
  OFFICE: 'office',
  SHOP: 'shop',
});

export const LEAD_PURPOSE = Object.freeze({
  BUY: 'buy',
  RENT: 'rent',
  INVEST: 'invest',
});

export const LEAD_STATUS_VALUES = Object.values(LEAD_STATUS);
export const LEAD_SOURCE_VALUES = Object.values(LEAD_SOURCE);
export const LEAD_PRIORITY_VALUES = Object.values(LEAD_PRIORITY);
export const PROPERTY_TYPE_VALUES = Object.values(PROPERTY_TYPE);
export const LEAD_PURPOSE_VALUES = Object.values(LEAD_PURPOSE);
