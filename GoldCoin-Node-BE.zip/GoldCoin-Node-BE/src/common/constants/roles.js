export const ROLES = Object.freeze({
  ADMIN: 'admin', // full access, manages users
  MANAGER: 'manager', // sees all leads, assigns leads to agents
  AGENT: 'agent', // sees only leads assigned to them
});

export const ROLE_VALUES = Object.values(ROLES);
