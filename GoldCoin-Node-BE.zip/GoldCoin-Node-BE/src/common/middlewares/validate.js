import { ApiError } from '#common/errors/ApiError.js';

/**
 * Validate request parts with zod schemas.
 * Parsed (typed, coerced, defaulted) values are stored in `req.validated`.
 * Controllers must read from `req.validated`, never from raw req.body/req.query.
 *
 *   router.post('/', validate({ body: createLeadSchema }), controller.create)
 */
export const validate = (schemas) => (req, _res, next) => {
  req.validated ??= {};
  const issues = [];

  for (const part of ['params', 'query', 'body']) {
    const schema = schemas[part];
    if (!schema) continue;

    const result = schema.safeParse(req[part] ?? {});
    if (result.success) {
      req.validated[part] = result.data;
    } else {
      for (const issue of result.error.issues) {
        issues.push({ field: [part, ...issue.path].join('.'), message: issue.message });
      }
    }
  }

  if (issues.length) throw ApiError.validation(issues);
  next();
};
