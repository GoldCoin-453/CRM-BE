/**
 * Strips MongoDB operator keys ($gt, $where, "a.b") from req.body and req.params
 * to prevent NoSQL injection. (req.query is read-only in Express 5 and is
 * always parsed through zod before use.)
 */
function clean(value) {
  if (Array.isArray(value)) return value.map(clean);
  if (value && typeof value === 'object') {
    for (const key of Object.keys(value)) {
      if (key.startsWith('$') || key.includes('.')) delete value[key];
      else value[key] = clean(value[key]);
    }
  }
  return value;
}

export function sanitizeInput(req, _res, next) {
  if (req.body) clean(req.body);
  if (req.params) clean(req.params);
  next();
}
