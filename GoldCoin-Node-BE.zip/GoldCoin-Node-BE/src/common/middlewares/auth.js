import { ApiError } from '#common/errors/ApiError.js';
import { verifyAccessToken } from '#common/utils/jwt.js';
import { User } from '#modules/users/user.model.js';

/**
 * Requires `Authorization: Bearer <token>`.
 * Sets `req.user = { id, role, name, email }`.
 */
export async function authenticate(req, _res, next) {
  const [scheme, token] = (req.headers.authorization ?? '').split(' ');
  if (scheme !== 'Bearer' || !token) {
    throw ApiError.unauthorized('Missing or invalid Authorization header');
  }

  const payload = verifyAccessToken(token);
  const user = await User.findById(payload.sub).select('name email role isActive').lean();
  if (!user || !user.isActive) throw ApiError.unauthorized('User not found or inactive');

  req.user = { id: String(user._id), role: user.role, name: user.name, email: user.email };
  next();
}

/**
 * Role based access. Use after `authenticate`.
 *   router.delete('/:id', authorize(ROLES.ADMIN, ROLES.MANAGER), ...)
 */
export const authorize =
  (...allowedRoles) =>
  (req, _res, next) => {
    if (!req.user) throw ApiError.unauthorized();
    if (!allowedRoles.includes(req.user.role)) throw ApiError.forbidden();
    next();
  };
