import rateLimit from 'express-rate-limit';
import { env } from '#config/env.js';
import { ApiError } from '#common/errors/ApiError.js';

const base = {
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  skip: () => env.isTest,
  handler: (_req, _res, next) => next(ApiError.tooManyRequests()),
};

/** General limiter for all API routes */
export const apiLimiter = rateLimit({
  ...base,
  windowMs: env.RATE_LIMIT_WINDOW_MS,
  limit: env.RATE_LIMIT_MAX,
});

/** Strict limiter for login / password endpoints (brute-force protection) */
export const authLimiter = rateLimit({
  ...base,
  windowMs: 15 * 60 * 1000,
  limit: 10,
});
