import mongoose from 'mongoose';
import { ApiError } from '#common/errors/ApiError.js';
import { env } from '#config/env.js';

/** Convert known library errors into ApiError so the client gets a clean message. */
function normalizeError(err) {
  if (err instanceof ApiError) return err;

  // Malformed JSON body
  if (err.type === 'entity.parse.failed') return ApiError.badRequest('Malformed JSON body');
  if (err.type === 'entity.too.large') return new ApiError(413, 'Request body too large');

  // JWT
  if (err.name === 'TokenExpiredError') {
    return new ApiError(401, 'Token expired', { code: 'TOKEN_EXPIRED' });
  }
  if (err.name === 'JsonWebTokenError' || err.name === 'NotBeforeError') {
    return new ApiError(401, 'Invalid token', { code: 'INVALID_TOKEN' });
  }

  // Mongoose
  if (err instanceof mongoose.Error.ValidationError) {
    const details = Object.values(err.errors).map((e) => ({ field: e.path, message: e.message }));
    return ApiError.validation(details);
  }
  if (err instanceof mongoose.Error.CastError) {
    return ApiError.badRequest(`Invalid value for ${err.path}`);
  }
  if (err?.code === 11000) {
    const fields = Object.keys(err.keyValue ?? {});
    return ApiError.conflict(`Duplicate value for: ${fields.join(', ') || 'unique field'}`, {
      fields,
    });
  }

  return null;
}

// Express identifies error handlers by their 4 arguments - keep `_next`.
export function errorHandler(err, req, res, _next) {
  const apiError = normalizeError(err);
  const statusCode = apiError?.statusCode ?? 500;

  if (statusCode >= 500) {
    req.log?.error({ err }, 'Unhandled error');
  } else {
    req.log?.warn({ code: apiError.code, message: apiError.message }, 'Request failed');
  }

  res.status(statusCode).json({
    success: false,
    error: {
      code: apiError?.code ?? 'INTERNAL_ERROR',
      message: apiError?.message ?? 'Something went wrong',
      ...(apiError?.details !== undefined && { details: apiError.details }),
      ...(!apiError && !env.isProduction && { stack: err.stack }),
    },
    requestId: req.id,
  });
}
