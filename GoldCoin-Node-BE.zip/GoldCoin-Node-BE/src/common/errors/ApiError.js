/**
 * Operational (expected) error that is safe to show to the client.
 * Throw it anywhere (service, middleware, controller) - the global
 * error handler turns it into a consistent JSON response.
 *
 *   throw ApiError.notFound('Lead not found');
 */
export class ApiError extends Error {
  /**
   * @param {number} statusCode HTTP status
   * @param {string} message    Human readable message
   * @param {object} [options]
   * @param {string} [options.code]    Machine readable code, e.g. LEAD_NOT_FOUND
   * @param {unknown} [options.details] Extra info (validation issues, ids...)
   */
  constructor(statusCode, message, { code, details } = {}) {
    super(message);
    this.name = 'ApiError';
    this.statusCode = statusCode;
    this.code = code ?? ApiError.defaultCode(statusCode);
    this.details = details;
    this.isOperational = true;
  }

  static defaultCode(status) {
    return (
      {
        400: 'BAD_REQUEST',
        401: 'UNAUTHORIZED',
        403: 'FORBIDDEN',
        404: 'NOT_FOUND',
        409: 'CONFLICT',
        422: 'UNPROCESSABLE_ENTITY',
        429: 'TOO_MANY_REQUESTS',
      }[status] ?? 'INTERNAL_ERROR'
    );
  }

  static badRequest(message = 'Bad request', details) {
    return new ApiError(400, message, { details });
  }

  static validation(details) {
    return new ApiError(400, 'Validation failed', { code: 'VALIDATION_ERROR', details });
  }

  static unauthorized(message = 'Authentication required') {
    return new ApiError(401, message);
  }

  static forbidden(message = 'You do not have permission to perform this action') {
    return new ApiError(403, message);
  }

  static notFound(message = 'Resource not found') {
    return new ApiError(404, message);
  }

  static conflict(message = 'Resource already exists', details) {
    return new ApiError(409, message, { details });
  }

  static tooManyRequests(message = 'Too many requests, please try again later') {
    return new ApiError(429, message);
  }
}
